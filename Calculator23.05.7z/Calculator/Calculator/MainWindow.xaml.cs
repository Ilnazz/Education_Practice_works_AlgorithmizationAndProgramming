﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private bool IsCalculateOperator(string s)
        {
            return s == "=";
        }

        private bool IsPrefixOperator(string s)
        {
            switch (s)
            {
                case "√":
                case "-":
                case "±":
                    return true;
                default:
                    return false;
            }
        }

        private bool IsPostfixOperator(string s)
        {
            switch (s)
            {
                case "/":
                case "%":
                case "*":
                case "1/x":
                case "-":
                case "+":
                case "±":
                    return true;
                default:
                    return false;
            }
        }

        private bool IsCleanOperator(string s)
        {
            switch (s)
            {
                case "←":
                case "CE":
                case "C":
                    return true;
                default:
                    return false;
            }
        }

        private bool IsMemoryOperator(string s)
        {
           switch (s)
            {
                case "MC": case "MR": case "MS": case "M+": case "M-":
                    return true;
                default:
                    return false;
            }
        }

        private bool IsComma(string s)
        {
            return s == ",";
        }

        private bool IsDigit(string s)
        {
            bool result = int.TryParse(s, out _);
            return result;
        }

        private bool DisplayIsEmpty()
        {
            return Display.Content.ToString() == "0";
        }

        private void DisplayClean()
        {
            Display.Content = "";
        }

        private void DisplayAdd(string s)
        {
            Display.Content += s;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (sender as Button);
            string t = btn.Content.ToString(); // t = token

            if (DisplayIsEmpty())
            {
                if (IsDigit(t) || IsPrefixOperator(t))
                {
                    DisplayClean();
                    DisplayAdd(t);
                }
            }
            else
            {
                if (IsDigit(t) || IsPostfixOperator(t))
                {
                    // create variable previous to check
                }
                if (IsCleanOperator(t))
                {
                    if (t == "CE")
                    {
                        // Clean entry
                        DisplayClean();
                    } else
                    {
                        // Clean all
                        DisplayClean();
                    }
                }
            }
        }
    }
}
