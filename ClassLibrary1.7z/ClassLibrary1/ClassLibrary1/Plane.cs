﻿using System;

namespace ClassLibrary1
{
    public class Plane : Vehicle
    {
        private int speed;
        public int Speed { get => speed; }

        private double ticketPrice;
        public double TicketPrice { get => ticketPrice; }

        private int numberOfSeats;
        public int NumberOfSeats { get => numberOfSeats; }

        public Plane(string name, int speed, double ticketPrice, int numberOfSeats)
            : base(name)
        {
            this.speed = speed;
            this.ticketPrice = ticketPrice;
            this.numberOfSeats = numberOfSeats;
        }

        public double TicketsTotalCost()
        {
            return ticketPrice * numberOfSeats;
        }

        public override void Print()
        {
            Console.WriteLine($"Самолет \"{name}\":" +
                $"\n\tСкорость: {speed}" +
                $"\n\tСтоимость билета: {ticketPrice}" +
                $"\n\tКоличество мест: {numberOfSeats}" +
                $"\n\tОбщая стоимость билетов: {TicketsTotalCost()}");
        }
    }
}
