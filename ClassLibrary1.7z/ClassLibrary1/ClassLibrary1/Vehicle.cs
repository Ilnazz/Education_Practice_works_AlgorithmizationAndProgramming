﻿namespace ClassLibrary1
{
    public abstract class Vehicle
    {
        protected string name;
        public string Name { get => name; }

        public Vehicle(string name)
        {
            this.name = name;
        }

        public abstract void Print();
    }
}
