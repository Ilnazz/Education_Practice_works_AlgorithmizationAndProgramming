﻿using System;

namespace ClassLibrary1
{
    class Car : Vehicle
    {
        private string color;
        public string Color { get => color; }

        private double price;
        public double Price { get => price; }

        private int year;
        public int Year { get => year; }

        public Car(string name, string color, double price, int year)
            : base(name)
        {
            this.color = color;
            this.price = price;
            this.year = year;
        }

        public override void Print()
        {
            Console.WriteLine($"Автомобиль \"{name}\":" +
                $"\n\tЦвет: {color}" +
                $"\n\tСтоимость: {price}" +
                $"\n\tГод выпуска: {year}");
        }
    }
}
