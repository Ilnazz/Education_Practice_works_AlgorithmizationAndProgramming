﻿using System;

namespace ClassLibrary1
{
    class Train : Vehicle
    {
        private int numberOfPassangers;
        public int NumberOfPassangers { get => numberOfPassangers; }

        private string departurePoint;
        public string DeparturePoint { get => departurePoint; }

        private string destinationPoint;
        public string DestinationPoint { get => destinationPoint; }

        public Train(string name, int nOfPassangers, string departure, string destination)
            : base(name)
        {
            numberOfPassangers = nOfPassangers;
            departurePoint = departure;
            destinationPoint = destination;
        }

        public override void Print()
        {
            Console.WriteLine($"Поезд \"{name}\":" +
                $"\n\tЧисло пассажиров: {numberOfPassangers}" +
                $"\n\tПункт отправления: {departurePoint}" +
                $"\n\tПункт назначения: {destinationPoint}");
        }
    }
}
