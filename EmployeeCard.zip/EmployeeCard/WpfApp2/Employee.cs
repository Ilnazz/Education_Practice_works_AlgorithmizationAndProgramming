﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeCard
{
    class Employee
    {
        public static int DocumentNumber { get; set; }
        public static string Institution { get; set; }
        public static string Qualification { get; set; }
        public static string Speciality { get; set; }

        public Employee(int docNumber, string institution, string qualification, string speciality)
        {
            DocumentNumber = docNumber;
            Institution = institution;
            Qualification = qualification;
            Speciality = speciality;
        }
    }
}
