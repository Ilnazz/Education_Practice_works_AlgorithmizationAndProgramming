﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Shop.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddToyPage.xaml
    /// </summary>
    public partial class AddEditToyPage : Page
    {
        Toy toy;

        public AddEditToyPage(Toy toy)
        {
            InitializeComponent();

            SupplierCB.ItemsSource = MainWindow.db.Supplier.ToList();
            SupplierCB.DisplayMemberPath = "Name";
            SupplierCB.SelectedItem = toy.Supplier;

            this.toy = toy;

            DataContext = toy;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (toy.Name != ""
                && toy.Image_Path != Shop.Constants.BLANK_IMAGE_PATH
                && toy.Supplier != null
                && toy.Price >= 0
                && toy.Quantity >= 0)
            {
                if (toy.Image_Path == Shop.Constants.BLANK_IMAGE_PATH)
                    toy.Image_Path = "";
                toy.ID_Supplier = (SupplierCB.SelectedItem as Supplier).ID_Supplier;
                if (toy.ID_Toy == 0)
                    MainWindow.db.Toy.Add(toy);
                MainWindow.db.SaveChanges();
                NavigationService.GoBack();
            }
            else
            {
                MessageBox.Show("Для сохранения зполните все данные.");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Img_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            dlg.DefaultExt = ".png";
            dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string filename = dlg.FileName;
                Img.Source = new BitmapImage(new Uri(filename));
            }
        }
    }
}
