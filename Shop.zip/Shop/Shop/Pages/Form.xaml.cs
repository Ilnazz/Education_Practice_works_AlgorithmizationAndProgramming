﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Shop
{
    /// <summary>
    /// Логика взаимодействия для Form.xaml
    /// </summary>
    public partial class Form : Page
    {

        List<Toy> toyList;

        public void SetUpToyList()
        {
            toyList = MainWindow.db.Toy.ToList();
            ToyList.ItemsSource = toyList.Where(toy => toy.Name != "");
            ToyList.Items.Refresh();
        }

        public Form()
        {
            InitializeComponent();

            SetUpToyList();

            List<Supplier> supplierList = MainWindow.db.Supplier.ToList();
            Supplier emptySupplier = new Supplier(); // Пустой поставщик для возможности сброса фильтра
            emptySupplier.Name = "- Любой -";
            supplierList.Insert(0, emptySupplier);
            SupplierCB.ItemsSource = supplierList;
            SupplierCB.DisplayMemberPath = "Name";

            if (MainWindow.currentUser.ID_Role == Shop.Constants.ROLE_USER)
            {
                ButtonAdd.Visibility = Visibility.Hidden;
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonChange.Visibility = Visibility.Hidden;
            }
        }

        private void SupplierCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SupplierCB.SelectedIndex == 0) // Все игрушки, любой поставщик
            {
                SetUpToyList();
                return;
            }
            
            Supplier supplier = SupplierCB.SelectedItem as Supplier;
            toyList = MainWindow.db.Toy.ToList().Where(toy => toy.ID_Supplier == supplier.ID_Supplier).ToList();
            ToyList.ItemsSource = toyList.Where(toy => toy.Name != "");
            ToyList.Items.Refresh();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            toyList = MainWindow.db.Toy.ToList().Where(toy => toy.Name.ToLower().Contains(ToyNameTB.Text.ToLower())).ToList();
            ToyList.ItemsSource = toyList.Where(toy => toy.Name != "");
            ToyList.Items.Refresh();
        }

        private void SortAscending_Checked(object sender, RoutedEventArgs e)
        {
            toyList.Sort((s1, s2) => s2.Name.CompareTo(s1.Name));
            ToyList.ItemsSource = toyList.Where(toy => toy.Name != "");
            ToyList.Items.Refresh();
        }

        private void SortDescending_Checked(object sender, RoutedEventArgs e)
        {
            toyList.Sort((s1, s2) => s1.Name.CompareTo(s2.Name));
            ToyList.ItemsSource = toyList.Where(toy => toy.Name != "");
            ToyList.Items.Refresh();
        }

        private void ButtonBuy_Click(object sender, RoutedEventArgs e)
        {
            Toy selectedToy = ToyList.SelectedItem as Toy;
            if (selectedToy != null)
            {
                selectedToy.Quantity -= 1;
                MainWindow.db.SaveChanges();
                SetUpToyList();
            }
            else
                MessageBox.Show("Игрушка не выбрана.");
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            Toy toy = new Toy();
            toy.Image_Path = Shop.Constants.BLANK_IMAGE_PATH;
            NavigationService.Navigate(new Pages.AddEditToyPage(toy));
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            Toy selectedToy = ToyList.SelectedItem as Toy;
            if (selectedToy != null)
            {
                MainWindow.db.Toy.Remove(selectedToy);
                MainWindow.db.SaveChanges();
                SetUpToyList();
            }
            else
                MessageBox.Show("Игрушка не выбрана.");
        }

        private void ButtonChange_Click(object sender, RoutedEventArgs e)
        {
            Toy selectedToy = ToyList.SelectedItem as Toy;

            if (selectedToy != null)
            {
                Pages.AddEditToyPage p = new Pages.AddEditToyPage(selectedToy);
                NavigationService.Navigate(p);
            }
            else
                MessageBox.Show("Игрушка не выбрана.");
        }

        private void ButtonRefresh_Click(object sender, RoutedEventArgs e)
        {
            SetUpToyList();
        }
    }
}
