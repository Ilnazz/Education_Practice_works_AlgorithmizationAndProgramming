﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Shop
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

    public static class Constants
    {
        public const int ROLE_USER = 1;
        public const int ROLE_ADMIN = 2;

        public const string BLANK_IMAGE_PATH = @"C:\Users\Ильназ\Desktop\Shop\Shop\Images\blank.png";
    }
}
