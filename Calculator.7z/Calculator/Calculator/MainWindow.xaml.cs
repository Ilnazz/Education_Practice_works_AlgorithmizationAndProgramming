﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private bool DisplayIsEmpty()
        {
            return Display.Content.ToString() == "0";
        }

        private void DisplayClean()
        {
            Display.Content = "";
        }

        private void DisplayAdd(string s)
        {
            Display.Content += s;
        }

        private string left;
        private bool leftHasComma;
        private Token leftType;

        private string op;
        private Token opType;

        private string right;
        private bool rightHasComma;
        private Token rightType;

        enum Token
        {
            Digit, Comma, PrefixOp, UnaryOp, BinaryOp, Clean, Backspace, Memory
        }

        private Token GetTokenType(string token)
        {
            switch (token) {
                case ",": return Token.Comma;
                case "←": return Token.Backspace;

                case "CE":
                case "C": return Token.Clean;

                case "MC":
                case "MR":
                case "MS":
                case "M+":
                case "M-": return Token.Memory;

                case "-":
                case "±": return Token.PrefixOp;

                case "/":
                case "%":
                case "*":
                case "+": return Token.BinaryOp;

                case "1/x":
                case "√": return Token.UnaryOp;

                default: return Token.Digit;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (sender as Button);
            string value = btn.Content.ToString();
            Token type = GetTokenType(value);

            if (DisplayIsEmpty())
            {
                if (type == Token.Digit || type == Token.PrefixOp)
                {
                    DisplayClean();
                    left += value;
                }
            }
            else
            {
                switch (type)
                {
                    case Token.Comma:
                        // Запятая
                        if (leftType == Token.Digit)
                        {
                            leftHasComma = true;
                            left += ".";
                        }
                        break;
                    case Token.Backspace:
                        // Стереть один символ

                        break;
                    case Token.Clean:
                        if (value == "CE")
                        {
                            // Удалить только что введенную запись
                        } else
                        {
                            // Очистить дислпей
                            DisplayClean();
                        }
                        break;
                    case Token.Memory:
                        // Оператор памяти

                        break;
                    case Token.PrefixOp:
                    case Token.BinaryOp:
                        // Бинарный оператор

                        break;
                    case Token.UnaryOp:
                        // Унарный оператор

                        break;
                    default:
                        // Цифра

                        break;
                }
            }

            DisplayAdd(value); // remake: update
        }
    }
}
