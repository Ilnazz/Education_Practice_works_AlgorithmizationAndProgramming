﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        enum Token
        {
            Digit, Comma, BinaryOp, UnaryOp, Calculate, Clean, Backspace, Memory
        }

        private string left = "0";
        private string op = "";
        private string right = "";

        private double memoryValue = 0;

        private string message = "";

        private Token GetTokenType(string token)
        {
            switch (token) {
                case ",": return Token.Comma;
                case "←": return Token.Backspace;

                case "CE":
                case "C": return Token.Clean;

                case "MC":
                case "MR":
                case "MS":
                case "M+":
                case "M-": return Token.Memory;

                case "-":
                case "/":
                case "%":
                case "*":
                case "+": return Token.BinaryOp;

                case "1/x":
                case "√":
                case "±": return Token.UnaryOp;

                case "=": return Token.Calculate;

                default: return Token.Digit;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (message != "")
            {
                message = "";
                op = right = "";
                left = "0";
            }

            string token = (sender as Button).Content.ToString();
            Token type = GetTokenType(token);

            switch (type)
            {
                case Token.Backspace: // Стереть один символ
                    if (right != "")
                        right = right.Substring(0, right.Length - 1);
                    else if (op != "")
                        op = "";
                    else
                        left = left.Length > 1 ? left.Substring(0, left.Length - 1) : "0";
                    break;

                case Token.Clean: // Оператор очистки
                    switch (token)
                    {
                        case "CE":
                            // Удалить только что введенную запись
                            if (right != "")
                                right = "";
                            else if (op != "")
                                op = "";
                            else
                                left = "0";
                            break;
                        case "C":
                            // Очистить дислпей
                            op = right = "";
                            left = "0";
                            break;
                    }
                    break;

                case Token.Memory: // Оператор памяти
                    if (op != "")
                        break;
                    switch (token)
                    {
                        case "MS":
                            memoryValue = double.Parse(left);
                            MemoryMark.Content = "M";
                            break;
                        case "MC":
                            memoryValue = 0;
                            MemoryMark.Content = "";
                            break;
                        case "MR":
                            left = memoryValue.ToString();
                            MemoryMark.Content = "";
                            break;

                        case "M-":
                            memoryValue -= double.Parse(left);
                            MemoryMark.Content = "M-";
                            break;

                        case "M+":
                            memoryValue += double.Parse(left);
                            MemoryMark.Content = "M+";
                            break;
                    }
                    break;

                case Token.BinaryOp: // Бинарный оператор
                    if (left == "-" || op != "")
                        break;
                    // Унарный минус
                    else if (left == "0")
                    {
                        left = "-";
                        break;
                    }
                    op = token;
                    break;

                case Token.UnaryOp: // Унарный оператор
                    if (left == "-" || op != "")
                        break;
                    double n = double.Parse(left);
                    switch (token)
                    {
                        case "1/x":
                            if (left != "0")
                                n = 1 / n;
                            else
                                message = "Ошибка";
                            break;
                        case "√":
                            if (double.Parse(left) >= 0)
                                n = Math.Sqrt(n);
                            else
                                message = "Ошибка";
                            break;
                        case "±":
                            n = -n;
                            break;
                    }
                    left = n.ToString();
                    break;

                case Token.Comma: // Запятая
                    if (op != "" && right == "")
                        right = "0,";
                    else if (op != "" && !right.Contains(","))
                        right += ",";
                    else if (left != "-" && !left.Contains(","))
                        left += ",";
                    break;

                case Token.Calculate:
                    // Вычисление результата операции над двумя числами
                    if (left == "-" || (op == "" && right == "") || (op != "" && right == ""))
                        break;
                    double l = double.Parse(left),
                           r = double.Parse(right);
                    switch (op)
                    {
                        case "+":
                            left = (l + r).ToString();
                            break;
                        case "-":
                            left = (l - r).ToString();
                            break;
                        case "*":
                            left = (l * r).ToString();
                            break;
                        case "/":
                            if (r == 0)
                            {
                                message = "Деление на ноль не определено.";
                                break;
                            }
                            left = (l / r).ToString();
                            break;
                        case "%":
                            left = (l / 100 * r).ToString();
                            break;
                    }
                    op = right = "";
                    break;

                default: // Цифра
                    if (op != "")
                        right = (right == "0") ? (token == "0" ? "0" : token) : right + token;
                    else
                        left = (left == "0") ? (token == "0" ? "0" : token) : left + token;
                    break;
            }
            if (message != "")
                Display.Content = message;
            else if (right != "")
            {
                Display.Content = right;
                ExpressionField.Content = left + " " + op;
            }
            else if (op != "")
            {
                Display.Content = op;
                ExpressionField.Content = left;
            }
            else
            {
                Display.Content = left;
                ExpressionField.Content = "";
            }
        }
    }
}
