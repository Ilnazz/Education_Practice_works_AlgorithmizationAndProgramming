﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BMR_Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private bool AreAllFieldsFilled()
        {
            return GenderComboBox.SelectedIndex != -1
                && AgeTextBox.Text != ""
                && WeightTextBox.Text != ""
                && GrowthTextBox.Text != ""
                && ActivityComboBox.SelectedIndex != -1;
        }

        private double GetActivityCoefficient(int index)
        {
            double coefficient;
            switch (index)
            {
                case 0: coefficient = 1.2; break;
                case 1: coefficient = 1.375; break;
                case 2: coefficient = 1.55; break;
                case 3: coefficient = 1.725; break;
                case 4: coefficient = 1.9; break;
                default: throw new Exception("Индекс должен быть в пределах 0 и 4.");
            }
            return coefficient;
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!AreAllFieldsFilled())
            {
                MessageBox.Show("Для вычисления необходимо заполнить все поля.");
                e.Handled = true;
                return;
            }

            string gender = GenderComboBox.SelectedItem.ToString();
            int age = int.Parse(AgeTextBox.Text);
            double weight = double.Parse(WeightTextBox.Text),
                growth = double.Parse(GrowthTextBox.Text);
            int activityIndex = ActivityComboBox.SelectedIndex;
            double activityCoefficient = GetActivityCoefficient(activityIndex);

            double BMR, TDEE;
            if (gender == "Мужской")
            {
                BMR = 66 + (13.7 * weight) + (5 * growth) - (6.8 * age);
            }
            else
            {
                BMR = 655 + (9.6 * weight) + (1.8 * growth) - (4.7 * age);
            }
            TDEE = BMR * activityCoefficient;

            ResultTextBlock.Text = $"БМР: {BMR}\n ОДРЭ: {TDEE}";
        }

        private void CleanButton_Click(object sender, RoutedEventArgs e)
        {
            GenderComboBox.SelectedIndex = -1;
            AgeTextBox.Text = "";
            WeightTextBox.Text = "";
            GrowthTextBox.Text = "";
            ActivityComboBox.SelectedIndex = -1;
            ResultTextBlock.Text = "";
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void AgeTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            bool result = int.TryParse(e.Text, out _);
            if (!result)
                e.Handled = true;
        }

        private void WeightTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            bool result = double.TryParse(e.Text, out _);
            if (!result)
                e.Handled = true;
        }

        private void GrowthTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            bool result = double.TryParse(e.Text, out _);
            if (!result)
                e.Handled = true;
        }
    }
}
